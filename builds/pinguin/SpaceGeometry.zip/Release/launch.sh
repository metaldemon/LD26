#!/bin/sh
mono LD26.exe
